# nrfutil-ble-sniffer documentation

# `ble-sniffer` command quick guide

nRF Util's nRF Sniffer for Bluetooth Low Energy (Bluetooth LE), also known as `ble-sniffer`, is a CLI tool that implements a Bluetooth LE sniffer for Nordic Semiconductor devices.

The sniffer supports the sniffer UART protocol version 3 and offers the following features:

* Detecting broadcasting devices and listing them
* Following devices by their addresses
* Following encrypted connections:

    * Identity Resolving Key (IRK)
    * Out of band (OOB)
    * Diffie-Hellman Private Key (DHPK)
    * Long Term Key (LTK)

See the [Sniffer command](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-ble-sniffer/guides/overview.html) section on the TechDocs platform for complete documentation.

## Sniffer device

nRF Sniffer for Bluetooth LE requires a compatible device that can act as a sniffer. Any Nordic Semiconductor's nRF52 Series device can act as sniffer.
See [Supported development kits and dongles](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-ble-sniffer/guides/requirements.html#supported-development-kits-and-dongles) for more information.

### Getting the sniffer firmware

When you [install the `nrfutil ble-sniffer` command](https://docs.nordicsemi.com/bundle/nrfutil/page/guides/installing_commands.html) (`nrfutil install ble-sniffer`), the sniffer firmware for compatible Nordic Semiconductor devices is extracted to the `/share/nrfutil-ble-sniffer/firmware` subdirectory under the [installation directory of nRF Util](https://docs.nordicsemi.com/bundle/nrfutil/page/guides/installing.html#installing-nrf-util-from-the-web-default).

You then need to program the sniffer firmware to one of the supported Nordic Semiconductor devices.

### Programming the sniffer firmware

Complete the following steps:

1. Locate the binary file for your compatible device at `/share/nrfutil-ble-sniffer/firmware` under the [installation directory of nRF Util](https://docs.nordicsemi.com/bundle/nrfutil/page/guides/installing.html#installing-nrf-util-from-the-web-default). The file name should match your device name.
1. Install nRF Util's `nrfutil device` command:
    ```bash
    nrfutil install device
    ```
1. Find your sniffer device using the following command:
    ```
    nrfutil device list
    ```
1. Program the HEX file using `nrfutil device`, replacing `<serial-number>` and `<hex>` with the serial number of your device and the HEX file name, respectively:
    ```bash
    nrfutil device program --serial-number <serial-number> --firmware <hex>
    ```

## Subcommands and use cases

Out of the box, nRF Sniffer for Bluetooth LE supplies a simple command line interface for sniffing in command line, but it is also compatible with Wireshark.

### Using the sniffer with Wireshark

To use the sniffer in Wireshark, complete the following steps:

1. Program your device by following the steps in [Programming the sniffer firmware](#programming-the-sniffer-firmware).
1. Run the bootstrap subcommand:
    ```bash
    nrfutil ble-sniffer bootstrap
    ```

This makes nRF Sniffer for Bluetooth LE runnable from Wireshark by copying a shim executable to Wireshark's external capture (extcap) directory.

You can now use nRF Sniffer for Bluetooth LE from Wireshark. See [Running nRF Sniffer](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-ble-sniffer/guides/running_sniffer.html)
for information on how to use the sniffer in Wireshark.

On Linux, you can verify that nRF Sniffer for Bluetooth LE is working as intended in Wireshark by listing sniffer interfaces in the terminal:

```
wireshark -D
```

You should see some output resembling the following:

```
...
xx. /dev/ttyACM0-4.0 (nRF Sniffer for Bluetooth LE)
```

### Using the sniffer as a command line program

nRF Sniffer for Bluetooth LE can perform basic sniffing in the terminal.

To start sniffing, run the `sniff` subcommand:
```
nrfutil ble-sniffer sniff --port <port>
```

Replace `<port>` with the port of your sniffer device.

You can customize the `sniff` subcommand in the following ways:

* The `sniff` subcommand stores the sniffer data in a PCAP file that is stored in the current directory. You can specify this PCAP file yourself with the `--output-pcap-file <path>` parameter. The file is named with the following format:
   ```
   YYYYDDMM-THHmmss.mmm-capture.pcap`
   ```

    In this naming format:

    * `YYYY` denotes year.
    * `DD` denotes the day, from 01 to 31.
    * `MM` denotes the month, from 01 to 12.
    * `HH` denotes the hour of the day, from 00 to 23.
    * `mm` denotes the minutes of the hour, from 00 to 59.
    * `ss` denotes the seconds of the minute, from 00 to 59.
    * `mmm` denotes the number of nanoseconds since the last whole minute.

* By default, there is no output that is printed to the screen. If you want output to stdout, pass `--log-output=stdout --json` to `nrfutil`. It is recommended to set the log level to `debug`.

* You can follow specific addresses using the `--follow` parameter with a BD address. Alternatively, devices with names can be followed with `--follow-by-name`.

## Sniffing HCI packets

nRF Sniffer for Bluetooth LE supports reading Host Controller Interface (HCI) packets for nRF Connect SDK applications.

See [Logging HCI packets](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-ble-sniffer/guides/hci_logger.html) for more information about how to set up HCI and use it with Wireshark.

After you set up HCI, you can also read HCI packets from a serial port using the following pattern (replace `<SERIALPORT>` with the serial port of your device):
```
nrfutil ble-sniffer hci --serialport <SERIALPORT>
```

The `hci` subcommand captures HCI packets read from the serial port and prints them to the terminal. It also stores them in a generated PCAP file that is located in the current working directory. You can inspect this PCAP file with Wireshark.
This PCAP file follows the same naming scheme as the PCAP file for the [`sniff` subcommand](#using-the-sniffer-as-a-command-line-program).
