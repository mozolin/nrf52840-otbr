# Copyright (c) 2022 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: BSD-3-Clause
#

# References:
#  - https://iridakos.com/programming/2018/03/01/bash-programmable-completion-tutorial
#  - man bash (search for 'complete' docs)

_nrfutil_completion()
{
    local cur
    local prev
    local words
    local cword
    local script
    local coms
    local com


    COMPREPLY=()

    # From the bash completion "/usr/share/bash-completion/bash_completion":
    #
    #     ...
    #
    #     Available OPTIONS:
    #         -n EXCLUDE  Characters out of $COMP_WORDBREAKS which should NOT be
    #                     considered word breaks. This is useful for things like scp
    #                     where we want to return host:path and not only path, so we
    #                     would pass the colon (:) as -n option in this case.
    #
    #     ...
    #
    #        $ _get_comp_words_by_ref -n : cur prev
    #
    # Bash seems to apply the same word break logic to "=" as well as ":" so we
    # add that to the -n flag too otherwise we get an unexpected argument count
    # through to the program. This perhaps because bash tries to help by split
    # on = so that --long-flag=val<tab> is treated a tab completion on just the
    # 'val' part instead of including the flag too but our Rust logic already
    # handles that long flag and the val so we allow it to go through.
    #
    _get_comp_words_by_ref -n "=:" -c cur -p prev -w words -i cword

    # Run in sub-shell using "()" so that the print out of the process & job id
    # is swallowed and doesn't interferre with the completion output
    # We do this instead of redirecting to /dev/null to avoid having the process
    # and job id printed by the shell because of `&`.
    #
    # NRFUTIL_IGNORE_MISSING_SUBCOMMAND means that nrfutil doesn't error if the
    # completion subcommand isn't available which might happen if the user has
    # uninstalled completion but still has an active shell
    (NRFUTIL_IGNORE_MISSING_SUBCOMMAND=true nrfutil completion server start &)

    # When called with 'bash' the completion query attempts to match the
    # __ltrim_colon_completions behviour which is part of
    # "/usr/share/bash-completion/bash_completion". That code helps with
    # completions around colons but we need the same help around equal signs
    # too so we implement the same approach in 'Shell.write' in the Rust code.
    #
    # 'mapfile' converts the output of a command into an array with one entry
    # per line
    mapfile -t opts < <(NRFUTIL_IGNORE_MISSING_SUBCOMMAND=true nrfutil completion query bash "$cword" -- $COMP_LINE)

    # Extract the first value as the 'mode' for compopt below
    local -r mode=${opts[0]}

    # Extract the second value as further compopt setting
    local -r quote=${opts[1]}

    # Take the rest of the array as the suggestions
    local -r shifted_opts=("${opts[@]:2}")

    # It is possible to provide $cur to compgen to ask it to filter on the
    # currently completing word but that seems to interfer with our : and =
    # handling so we don't ask it to do that and instead assume that we'll do
    # all the filtering in the Rust code 
    COMPREPLY=("${shifted_opts[@]}")

    # Set comptopt based on the mode returned from the rust code. This is what
    # tells the shell to treat the suggestions as potential file names or as
    # incomplete values or anything else which might impact the shell behaviour
    # (mostly whether or not to add a space after completing the value but also
    # how to display suggestions that match files and directories.)
    compopt -o "${mode}";

    # Optionally set 'noquote' if instructed to by the completion output. This is
    # used to disable path quoting when in bash on Windows as Windows wants
    # backslashes and bash seems to want to keep on escaping those backslashes
    # which is a poor user experience as there is an explosion of backslashes in
    # a normal interaction.
    if [ "$quote" = "noquote" ]; then
        compopt -o "noquote";
    fi

    return 0
}

complete -F _nrfutil_completion nrfutil

# Windows will usually autocomplete the entire name of the executable (including extension)
# OSTYPE is set by bash on startup, and will for MinGW (git bash) include the string "msys".
if [[ "$OSTYPE" =~ ^msys ]]; then
    complete -F _nrfutil_completion "nrfutil.exe"
fi
