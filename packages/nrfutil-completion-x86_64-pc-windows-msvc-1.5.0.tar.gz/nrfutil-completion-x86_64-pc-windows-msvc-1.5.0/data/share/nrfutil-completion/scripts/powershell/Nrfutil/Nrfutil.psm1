# Copyright (c) 2022 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: BSD-3-Clause
#

# To debug variables you can use syntax like:
#
#    $myvar | Out-File -Append -FilePath "/path/to/log"
#
# As I don't think it is possible to see debug output directly and if so, it is
# confusing with the actual completion interaction

$scriptblock = {
    param($wordToComplete, $commandAst, $cursorPosition)
        # Get command line elements as string array
        [String[]]$script:elements = $commandAst.CommandElements | ForEach-Object { "$_" };

        [String]$script:commandText = $commandAst.Extent.Text;
        [Int32]$script:commandLength = $commandAst.Extent.Text.Length;

        [Int32]$script:index = -1;

        if ( $cursorPosition -gt $script:commandLength ) {
            # If the cursorPosition is after the end of the line then we're
            # completing a entry after the command so we use the length of the
            # argument list to represent the index
            [Int32]$script:index = $commandAst.CommandElements.Count;

        } else {
            # Search the ast of the command to find the node that contains the
            # cursor position provided to this completion function. We increment
            # the script-scope index variable to track the index of the node that
            # matches the cursor position so that we can provide that to the
            # completion code. This is because the completion executable expects
            # the index of the word in the command line to be completed whereas
            # PowerShell provides the character index into the string of the
            # command line where the cursor is.
            #
            $commandAst.CommandElements | ForEach-Object {
                if ( $_.Extent.StartColumnNumber -le $cursorPosition ) {
                    $script:index++;
                }
            }
        }

        # If the word-to-complete is empty then we represent it as a double
        # quotes in single quotes as powershell doesn't properly pass an empty
        # string as an argument to command
        if ( $wordToComplete -eq "" ) {
            $wordToComplete = '""'
        }

        try {
            # Set environment variable for processes so that we don't error if
            # 'completion' is not available as a subcommand
            $env:NRFUTIL_IGNORE_MISSING_SUBCOMMAND='true'

            Start-Process nrfutil -NoNewWindow -ArgumentList completion, server, start

            # Run the completion helper and create completion items from the result
            # "@" splats the array as arguments to the command
            nrfutil completion query powershell $script:index -- @script:elements | ForEach-Object {
                $obj = ConvertFrom-Json $_
                # Default tooltip to display - powershell doesn't seem to like null or empty values
                $tooltip = if ($obj.tooltip -ne $null) { $obj.tooltip } else { $obj.display }
                [System.Management.Automation.CompletionResult]::new($obj.value, $obj.display, 'ParameterValue', $tooltip)
            }
        }
        finally {
            # Remove environment variable so that it doesn't pollute the user's environment
            Remove-Item "Env:\NRFUTIL_IGNORE_MISSING_SUBCOMMAND"
        }
}

Register-ArgumentCompleter -Native -CommandName nrfutil -ScriptBlock $scriptblock

# Windows will usually autocomplete the entire name of the executable (including extension)
if ( [System.Environment]::OSVersion.Platform -eq "Win32NT" ) {
    Register-ArgumentCompleter -Native -CommandName nrfutil.exe -ScriptBlock $scriptblock
}
