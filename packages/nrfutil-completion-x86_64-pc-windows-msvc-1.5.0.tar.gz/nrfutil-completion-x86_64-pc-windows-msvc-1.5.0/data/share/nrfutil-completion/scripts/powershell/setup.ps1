# Copyright (c) 2022 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: BSD-3-Clause
#

# Find path to the script we're in
$script_path = $MyInvocation.MyCommand.Path

# Add folder to module path with the correct separator
$script_folder = Split-Path -Path $script_path -Parent;

# Use platofrm appropriate path separator (':' or ';')
$separator = [IO.Path]::PathSeparator

$env:PSModulePath += ${env:PSModulePath} + ${separator} + ${script_folder}

# Import the module to set up the completion hook
Import-Module Nrfutil
