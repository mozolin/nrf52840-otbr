# Copyright (c) 2022 Nordic Semiconductor ASA
#
# SPDX-License-Identifier: BSD-3-Clause
#

# nrfutil zsh setup

source_path=${(%):-%N}
directory=$(dirname $source_path)

# Add directory to the fpath so that zsh finds our _nrfutil file
fpath+=($directory)
