# nrfutil-sdk-manager documentation

# `sdk-manager` command quick guide

nRF Util's `sdk-manager` is a CLI tool for managing SDK and toolchain installations for the [nRF Connect SDK](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/index.html).

Each version of the nRF Connect SDK has an associated [toolchain](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/installation/recommended_versions.html#nrf_connect_sdk_toolchain), which includes tools and modules specific to the nRF Connect SDK that are required to build nRF Connect SDK samples and applications.
Multiple SDK versions can share the same toolchain version (for example, the nRF Connect SDK v2.4.1 is reusing the toolchain v2.4.0).

**Note:** `sdk-manager` is set to replace the `toolchain-manager` nRF Util command.
The `sdk-manager` command is able to detect the toolchains installed with `toolchain-manager`.

## Default installation locations

The `sdk-manager` has its own, dedicated installation directory for downloading and installing SDKs and toolchains. Its location depends on your operating system:

| Operating System | Default installation location for bundles | Notes |
|-----------------|------------------------------|--------|
| Windows | `C:\ncs` | [Can be changed using a flag or permanently](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_config_settings.html#modifying-configuration-settings). |
| Linux | `$HOME/ncs` (or `~/ncs`) | [Can be changed using a flag or permanently](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_config_settings.html#modifying-configuration-settings). |
| macOS | `/opt/nordic/ncs` | Cannot be changed - [read why](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_installing.html#default-installation-locations). |

For more information about how bundles are structured within this directory, see [Installing and uninstalling with SDK manager](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_installing.html).

## Available subcommands

To see the list of subcommands and available operations, run `nrfutil sdk-manager --help`.

## Basic usage examples

Below are some basic usage examples of the `sdk-manager` command.

### Checking available SDKs and toolchains

The following command updates and prints the list of _stable_ SDK bundles and their corresponding toolchain bundles that are available for download or installed on your machine (or both):

```
nrfutil sdk-manager search
```

The command outputs the list of versions and their status for the default or selected [installation directory](#default-installation-locations):

```
Version   SDK             Toolchain
v2.7.0    Installed       Not Installed
v2.3.0    Not Installed   Not Installed
v2.2.0    Not Installed   Not Installed
v2.1.0    Not Installed   Not Installed
v2.0.0    Not Installed   Installed
```

You can install the SDK and toolchain versions that are `Available`.
For the description of other possible statuses and information about how to show all available SDKs and toolchains, see [Searching for available SDKs and toolchains](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_searching.html).

### Installing SDKs and toolchains

To install a specific version, use the `nrfutil sdk-manager install` command and specify the version you want to install.
For example, the following command installs both the SDK bundles and its corresponding toolchain bundle for the nRF Connect SDK v2.7.0:
```
nrfutil sdk-manager install v2.7.0
```

The installation can take several minutes.

If you have either an SDK or a toolchain bundle already installed, this command installs the missing bundle for the provided version.
If the SDK version you are installing is reusing a toolchain version that you have already installed, the command will not install the toolchain again.

For more information about the `install` command, see [Installing and uninstalling with SDK manager](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_installing.html).

### Uninstalling SDKs and toolchains

To remove both the SDK and its associated toolchain version, use the top-level `uninstall` subcommand.

For example, the following command removes both the SDK and toolchain v2.7.0 bundles:
```
nrfutil sdk-manager uninstall v2.7.0
```
If the toolchain version is used by other SDKs, the toolchain is not removed by this command.

You can also remove an SDK bundle or a toolchain bundle separately using the `sdk uninstall` or the `toolchain uninstall` subcommands, respectively.
For more information, see [Uninstalling only the SDK or the toolchain](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_installing.html#uninstalling-only-the-sdk-ot-the-toolchain).

### Checking the setup information

To check the configuration settings for `sdk-manager`, run the following command:
```
nrfutil sdk-manager config show
```

For more information, see the [Configuration settings](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-sdk-manager/guides/sdk_manager_config_settings.html) page.
