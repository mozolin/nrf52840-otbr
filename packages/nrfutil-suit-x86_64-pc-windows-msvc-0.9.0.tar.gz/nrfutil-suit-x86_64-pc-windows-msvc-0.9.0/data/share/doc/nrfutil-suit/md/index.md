# nrfutil-suit documentation

# SUIT command

nRF Util's `suit` command is a CLI tool for performing a series of SUIT operations, such as inspecting SUIT manifest files or uploading SUIT envelopes.
The tool is meant for use with Nordic Semiconductor devices that support the [Device Firmware Update using SUIT](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_dfu.html).

All nRF Util's `suit` subcommands (except for `envelope-hierarchy`) connect to a device over a serial port and then issue one or multiple commands to the device to perform SUIT operations over SMP over UART.

Before you use these subcommands, make sure you are familiar with [SUIT basics](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_intro.html) and especially [SUIT manifests](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_manifest_overview.html).

## Available subcommands

To see the list of subcommands and available device operations, run `nrfutil suit --help`.

## Basic usage examples

Below are some basic usage examples of the `suit` command.

### Listing manifest hierarchy

The following command prints the hierarchy of the manifests for the provided `nordic-top.suit` envelope file:

```
nrfutil suit envelope-hierarchy --envelope-file nordic-top.suit
```

This subcommand lists the root manifest, and then manifests of the dependencies (and dependencies of those, if any).
This command prints output similar to the following one:

```
root:
  version: 1
  sequence_number: 1
  component_id: INSTLD_MFST/0xf03d385ea7315605b15d037f6da6097f (nRF54H20_nordic_top)
  digest:
    algorithm_id: sha256
    bytes: 68b3b7a8e2be6d46ab1d21fa463a649c0f03a74951bc733930717840b91e2fa1
  common:
    components:
    - CAND_MFST/0
    - INSTLD_MFST/0xd96b40b7092b5cd1a59f9af80c337eba (nRF54H20_sec)
    - INSTLD_MFST/0xc08a25d735e6592cb7ad43acc8d1d1c8 (nRF54H20_sys)
    dependencies:
    - CAND_MFST/0
    - INSTLD_MFST/0xd96b40b7092b5cd1a59f9af80c337eba (nRF54H20_sec)
    - INSTLD_MFST/0xc08a25d735e6592cb7ad43acc8d1d1c8 (nRF54H20_sys)
  integrated_dependencies: []
```


In this output:

- `version` - version of the manifest format; corresponds to [`suit-manifest-version`](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_manifest_overview.html#suit-manifest-version).
- `sequence_number` - used as anti-rollback counter; corresponds to [`suit-manifest-sequence-number`](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_manifest_overview.html#suit-manifest-sequence-number).
- `component_id` - references [`suit-components`](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_manifest_overview.html#suit-common) that are to be targeted by the manifest.
- `digest` - calculated over the manifest.
- `common - components` - IDs for all components from [`suit-components`](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_manifest_overview.html#suit-common). Component IDs are interpreted using Nordic conventions. Any component IDs that do not match known conventions are printed out in their raw format as lists of hex encoded bytestrings.
- `common - dependencies` - IDs for components from [`suit-components`](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_manifest_overview.html#suit-common) that are to be treated as Dependency Manifest Envelopes.

### List manifests on the device

The following command lists all manifests on the device connected to the serial port `COM7` on Windows (run [`nrfutil device list`](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-device/guides/programming.html#listing-device-serial-numbers-and-traits) to check the serial port name for your OS):

```
nrfutil suit manifests --serial-port COM7
```

The `--serial-port` argument can also take other values. Use the [`--help`](https://docs.nordicsemi.com/bundle/nrfutil/page/guides/getting_started.html#help-commands) argument with your command to list them.

This command prints output similar to the following one:
```
role(10) (Nordic Top)
	classId: f03d385e-a731-5605-b15d-037f6da6097f (Nrf54H20NordicTop)
	vendorId: 7617daa5-71fd-5a85-8f94-e28d735ce9f4 (Nordicsemi)
	downgradePreventionPolicy: downgrade forbidden
	independentUpdateabilityPolicy: independent update allowed
	signatureVerificationPolicy: signature verification on update and boot
	digestVerificationStatus: digest match, signature check not performed
	digest: 3eb71834b18c42acbab67d844bb2086fd719f77a9f0f3904b27cc085f246c07f
	digestAlgorithm: sha256
	sequenceNumber: 394496
	semantic version: 0.6.5

role(11) (SDFW and SDFW recovery updates)
	classId: d96b40b7-092b-5cd1-a59f-9af80c337eba (Nrf54H20Sec)
	vendorId: 7617daa5-71fd-5a85-8f94-e28d735ce9f4 (Nordicsemi)
	downgradePreventionPolicy: downgrade forbidden
	independentUpdateabilityPolicy: independent update forbidden
	signatureVerificationPolicy: signature verification on update and boot
	digestVerificationStatus: digest match, signature check not performed
	digest: 094eb166f60d4412e4229589cf1209b4401ad6d0130e74996d8ab109377db10e
	digestAlgorithm: sha256
	sequenceNumber: 117440768
	semantic version: 7.0.1

role(12) (System Controller Manifest)
	classId: c08a25d7-35e6-592c-b7ad-43acc8d1d1c8 (Nrf54H20Sys)
	vendorId: 7617daa5-71fd-5a85-8f94-e28d735ce9f4 (Nordicsemi)
	downgradePreventionPolicy: downgrade forbidden
	independentUpdateabilityPolicy: independent update forbidden
	signatureVerificationPolicy: signature verification on update and boot
	digestVerificationStatus: digest match, signature check not performed
	digest: f9b490c772f5b8729e1e6437139f621e94b1ddfe55a3cba91ed308eff00e4afb
	digestAlgorithm: sha256
	sequenceNumber: 33949440
	semantic version: 2.6.7

[...]
```

You can also list specific classes of the SUIT manifest using the `nrfutil device x-suit-manifest-info-get` command
with the `--class-id` or `--known-class-id` flags.
For example, the following command provides information about the `role(10) (Nordic Top)` manifest from the output above on a device with the serial number `1234567890`:

```
nrfutil device x-suit-manifest-info-get --serial-number 1234567890 --known-class-id nRF54H20_nordic_top
```

### Uploading a specific SUIT envelope

The following command uploads the SUIT envelope file `root.suit` to the device connected to the serial port `COM7` on Windows (run [`nrfutil device list`](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-device/guides/programming.html#listing-device-serial-numbers-and-traits) to check the serial port name for your OS):

```
nrfutil suit upload-envelope --envelope-file root.suit --serial-port COM7
```

This command uploads the file and produces no additional output.

### Uploading a raw cache file

The cache is a temporary storage area used during the DFU process. It can hold multiple partitions (pools). The ID number of the partition determines the `CACHE_POOL` ID in the SUIT manifest.
For more information about `CACHE_POOL` in SUIT, see [SUIT components](https://docs.nordicsemi.com/bundle/ncs-latest/page/nrf/app_dev/device_guides/working_with_nrf/nrf54h/ug_nrf54h20_suit_components.html).

The following command uploads the SUIT raw cache file `dfu_cache_partition_1.bin` to the cache pool with ID `1` on the device connected to the serial port `COM7` on Windows (run [`nrfutil device list`](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-device/guides/programming.html#listing-device-serial-numbers-and-traits) to check the serial port name for your OS):

```
nrfutil-suit upload-cache-raw --serial-port COM7 --cache-file dfu_cache_partition_1.bin --pool 1
```

The `--pool` option is always required and its value must match the DFU cache partition defined in the devicetree source file.

This command uploads the given binary file and produces no additional output.

### Installing an already uploaded envelope

The following command installs a previously uploaded SUIT envelope file on the device connected to the serial port `COM7` on Windows (run [`nrfutil device list`](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-device/guides/programming.html#listing-device-serial-numbers-and-traits) to check the serial port name for your OS):

```
nrfutil suit install --serial-port COM7
```

This command installs the file and produces no additional output.

You can also combine uploading and installing. For example:
```
nrfutil suit upload-envelope --envelope-file root.suit --install --serial-port COM7
```

### Erasing DFU partitions

The DFU partition is a specific area of memory where the SUIT envelope is stored, as defined in the devicetree source file.

The following command cleans up the DFU partition and the DFU cache partitions on the device connected to the serial port `COM7` on Windows (run [`nrfutil device list`](https://docs.nordicsemi.com/bundle/nrfutil/page/nrfutil-device/guides/programming.html#listing-device-serial-numbers-and-traits) to check the serial port name for your OS):

```
nrfutil-suit cleanup --serial-port COM7
```

This command performs the cleanup and produces no additional output.
